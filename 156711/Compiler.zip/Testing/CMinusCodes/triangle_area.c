void main(void)
{
    int a;
    int b;
    
    a = input();
    b = input();
    output((a * b) / 2);
}