%{
#include "funcs.h"
#include "intermediate.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

FILE *fp;
Bloco *buffer = NULL;
Lex *lex;

int openned = 0;
int yylineno;
int valyy;
char yytext[64];


AASNode *root;
SimbCell simbTable[MAX];

int yyerror(char *s);

int yylex(void);

%}

%union {
    int intValue;
    char* stringValue;
    AASNode* node;
}

// %debug

%start programa
%token NUM
%token ID
%token IF ELSE WHILE INT RETURN VOID COMP DIF GT LT GE
%token LE SOMA SUB MULT DIV ATR
%token PTV VIR APAR FPAR ACOL   
%token FCOL ACHV FCHV
%token CMT
%token INPUT OUTPUT
%type <node> programa declaracao_lista declaracao var_declaracao tipo_especificador fun_declaracao params param_lista param composto_decl local_declaracoes statement_lista statement expressao_decl selecao_decl iteracao_decl retorno_decl expressao var simples_expressao relacional soma_expressao aditivo termo operador_multiplicativo fator ativacao args arg_lista id num input_stmt output_stmt

%left SOMA SUB
%left MULT DIV


%%
programa: declaracao_lista { 
            root = newAASNodeStmt(KProg);
            addAASNode(root, $1);
        }
        ;

declaracao_lista: declaracao_lista declaracao {
                    $$ = $1;
                    addAASNodeSibling($$, $2);
                }
                | declaracao { $$ = $1; }
                ;

declaracao: var_declaracao { $$ = $1; }
          | fun_declaracao { $$ = $1; }
          ;

var_declaracao: tipo_especificador id PTV {
                    $$ = $1;
                    $2->type = $1->type;
                    addAASNode($$, newAASNodeStmt(KVar));
                    $$->children->line = $2->line;
                    $$->children->type = $1->type;
                    $$->children->name = copyString($2->name);
                    $$->children->escopo = copyString("global");

                }
                | tipo_especificador id ACOL num FCOL PTV {
                    $$ = $1;
                    $2->type = $1->type;
                    addAASNode($$, newAASNodeStmt(KVet));
                    $$->children->line = $2->line;
                    $$->children->type = $1->type;
                    $$->children->name = copyString($2->name);
                    $$->children->escopo = copyString("global");
                    $$->children->value = $4->value; // Definir o valor do array
                    addAASNode($$->children, $2); 
                    addAASNode($$->children, $4);
                }
                ;

tipo_especificador: INT { 
                        $$ = newAASNodeExp(KType); 
                        $$->type = KInt; 
                        }
                    | VOID {
                        $$ = newAASNodeExp(KType);
                        $$->type = KVoid;
                    }
                    ;

fun_declaracao: tipo_especificador id APAR params FPAR composto_decl {
        $$ = $1;
        $2->type = $1->type;
        addAASNode($$, newAASNodeStmt(KFunc));
        $$->children->line = $2->line;
        $$->children->type = $1->type;
        $$->children->name = copyString($2->name);
        // printf("Funcao: %s\n", $$->children->name);
        $$->children->escopo = copyString("global");
        updateEscopo($4, $$->children->name);
        updateEscopo($6, $$->children->name);
        addAASNode($$->children, $4);
        addAASNode($$->children, $6);
}
    ;

params: param_lista { $$ = $1; }
    | VOID { $$ = NULL; }
    ;

param_lista: param_lista VIR param { 
        $$ = $1;
        addAASNodeSibling($$, $3);
    }
    | param { $$ = $1; }
    ;

param: tipo_especificador id {
        $$ = $1;
        $2->type = $1->type;
        $2->escopo = copyString($$->escopo);
        addAASNode($$, newAASNodeStmt(KVar));
        $$->children->line = $2->line;
        $$->children->type = $1->type;
        $$->children->name = copyString($2->name);
    }
    | tipo_especificador id ACOL FCOL {
        $$ = $1;
        $2->type = $1->type;
        $2->escopo = copyString($$->escopo);
        addAASNode($$, newAASNodeStmt(KVet));
        $$->children->line = $2->line;
        $$->children->type = $1->type;
        $$->children->name = copyString($2->name);
    }
    ;

composto_decl: ACHV local_declaracoes statement_lista FCHV {
        $$ = newAASNodeStmt(KCompound);
        if ($2 != NULL) {
            addAASNode($$, $2);
            if ($3 != NULL) {
                addAASNodeSibling($2, $3);
            }
        } else if ($3 != NULL) {
            addAASNode($$, $3);
        }
    }
    ;

local_declaracoes: local_declaracoes var_declaracao {
        if ($1 == NULL) {
            $$ = $2;
        } else {
            $$ = $1;
            addAASNodeSibling($$, $2);
        }
    }
    | { $$ = NULL; }
    ;

statement_lista: statement_lista statement {
        if ($1 == NULL) {
            $$ = $2;
        } else {
            $$ = $1;
            addAASNodeSibling($$, $2);
        }
    }
    | { $$ = NULL; }
    ;

statement: expressao_decl { $$ = $1; }
    | composto_decl { $$ = $1; }
    | selecao_decl { $$ = $1; }
    | iteracao_decl { $$ = $1; }
    | retorno_decl { $$ = $1; }
    | input_stmt { $$ = $1; }
    | output_stmt { $$ = $1; }
    ;

input_stmt: INPUT APAR var FPAR PTV {
        $$ = newAASNodeStmt(KInput);
        addAASNode($$, $3);
        $$->line = $3->line;
    }
    ;

output_stmt: OUTPUT APAR expressao FPAR PTV {
        $$ = newAASNodeStmt(KOutput);
        addAASNode($$, $3);
        $$->line = $3->line;
    }
    ;

expressao_decl: expressao PTV { $$ = $1; }
    | PTV { $$ = NULL; }
    ;

selecao_decl: IF APAR expressao FPAR statement {
        $$ = newAASNodeStmt(KIf);
        addAASNode($$, $3);
        addAASNode($$, $5);
    }
    | IF APAR expressao FPAR statement ELSE statement {
        $$ = newAASNodeStmt(KIf);
        addAASNode($$, $3);
        addAASNode($$, $5);
        addAASNode($$, $7);
    }
    ;

iteracao_decl: WHILE APAR expressao FPAR statement{
        $$ = newAASNodeStmt(KWhile);
        addAASNode($$, $3);
        addAASNode($$, $5);
    }
    ;

retorno_decl: RETURN PTV { 
        $$ = newAASNodeStmt(KReturn);
        $$->name = copyString("void");
        $$->type = KVoid;
        $$->line = lex->line;
    }   
    | RETURN expressao PTV {
        $$ = newAASNodeStmt(KReturn);
        $$->name = copyString("int");
        $$->type = $2->type;
        $$->line = $2->line;
        addAASNode($$, $2);
    }
    ;


expressao: var ATR expressao {
        $$ = newAASNodeStmt(KAssign);
        $$->name = copyString($1->name);
        $$->type = $1->type;
        $$->line = $1->line;
        addAASNode($$, $1);
        addAASNode($$, $3);
    }
    | simples_expressao {
        $$ = $1;
    }
    ;

var: id { 
        $$ = $1;
    }
    | id ACOL expressao FCOL {
        $$ = newAASNodeExp(KVetId);
        $$->type = $1->type;
        $$->line = $1->line;
        $$->name = copyString($1->name);
        $$->escopo = copyString($1->escopo);
        addAASNode($$, $1);
        addAASNode($$, $3);
    }
    ;

simples_expressao: soma_expressao relacional soma_expressao {
    $$ = $2;
    $$->type = KInt;
    addAASNode($$, $1);
    addAASNode($$, $3);
}
    | soma_expressao {
        $$ = $1;
    }
    ;


relacional: LE { $$ = newAASNodeExp(KOp); $$->token = LE; }
    | LT { $$ = newAASNodeExp(KOp); $$->token = LT; }
    | GT { $$ = newAASNodeExp(KOp); $$->token = GT; }
    | GE { $$ = newAASNodeExp(KOp); $$->token = GE; }
    | COMP { $$ = newAASNodeExp(KOp); $$->token = COMP; }
    | DIF { $$ = newAASNodeExp(KOp); $$->token = DIF; }
    ;

soma_expressao: soma_expressao aditivo termo {
    $$ = $2;
    addAASNode($$, $1);
    addAASNode($$, $3);
}
    | termo {
        $$ = $1;
    }
    ;

aditivo: SOMA { $$ = newAASNodeExp(KOp); $$->token = SOMA; $$->type = KInt; }    
       | SUB { $$ = newAASNodeExp(KOp); $$->token = SUB; $$->type = KInt; }
       ;

termo: termo operador_multiplicativo fator {
    $$ = $2;
    addAASNode($$, $1);
    addAASNode($$, $3);
}
    | fator {
        $$ = $1;
    }
    ;

operador_multiplicativo: MULT { $$ = newAASNodeExp(KOp); $$->token = MULT; $$->type = KInt; }
                       | DIV { $$ = newAASNodeExp(KOp); $$->token = DIV; $$->type = KInt; }
                       ;

fator: APAR expressao FPAR { $$ = $2; }
    | var { $$ = $1; }
    | ativacao { $$ = $1; }
    | num { $$ = $1; }
    ;

ativacao: id APAR args FPAR {
    if (strcmp($1->name, "input") == 0) {
        $$ = newAASNodeStmt(KInput);
        $$->type = KInt;
        $$->token = lex->token;
        $$->line = lex->line;
        $$->name = copyString("input");
    } else if (strcmp($1->name, "output") == 0) {
        $$ = newAASNodeStmt(KOutput);
        $$->type = KVoid;
        $$->token = lex->token;
        $$->line = lex->line;
        $$->name = copyString("output");
        addAASNode($$, $3);
    } else {
        $$ = newAASNodeStmt(KCall);
        $$->type = $1->type;
        $$->token = lex->token;
        $$->line = lex->line;
        $$->name = copyString($1->name);
        addAASNode($$, $3);
    }
}
| id APAR FPAR {
    if (strcmp($1->name, "input") == 0) {
        $$ = newAASNodeStmt(KInput);
        $$->type = KInt;
        $$->token = lex->token;
        $$->line = lex->line;
        $$->name = copyString("input");
    } else if (strcmp($1->name, "output") == 0) {
        $$ = newAASNodeStmt(KOutput);
        $$->type = KVoid;
        $$->token = lex->token;
        $$->line = lex->line;
        $$->name = copyString("output");
    } else {
        $$ = newAASNodeStmt(KCall);
        $$->type = $1->type;
        $$->token = lex->token;
        $$->line = lex->line;
        $$->name = copyString($1->name);
    }
}
    ;

args: arg_lista { $$ = $1; }
    ;

arg_lista: arg_lista VIR expressao {
        if ($1 == NULL) {
            $$ = $3;
        } else {
            $$ = $1;
            addAASNodeSibling($$, $3);
        }
    }
    | expressao {
        $$ = $1;
    }
    ;

id: ID {
        $$ = newAASNodeExp(KId);
        $$->token = lex->token;
        $$->line = lex->line;
        $$->type = KInt;
        $$->name = copyString(lex->lexema);
        $$->escopo = copyString("global");
    }
    ;

num: NUM {
        $$ = newAASNodeExp(KConst);
        $$->value = atoi(lex->lexema);
        $$->type = KInt;
        $$->line = lex->line;
        $$->token = lex->token;
        $$->escopo = copyString("global");
    }

%%
int yyerror(char *s) {
    if (lex->token == ER) {
        printf("%s '%s' INVALIDO [linha: %d, coluna: %d]\n", s, lex->lexema, lex->line + 1, lex->column);
    } else {
        printf("%s '%s' INVALIDO [linha: %d]\n", s, lex->lexema, lex->line + 1);
    }
    return 0;
}

int yylex(void) {
    int token;
    do {
        token = get_lexema(buffer, lex, fp);
        if (token == ER) {
            yyerror("ERRO LEXICO:");
            return ER;
        }
    } while (token == CMT);
    strcpy(yytext, lex->lexema);
    yylineno = lex->line;
    if (token == NUM) {
        yylval.intValue = atoi(lex->lexema);
    }
    return token;
}

int main(int argc, char *argv[]) {
    int option = -1;
    int run_all = 0;
    if (argc < 2) { // Verifica se o arquivo foi passado como argumento
        printf("Usage: %s <filename> [-l|-p|-s]\n", argv[0]);
        return 1;
    }

    // Verifica se alguma flag foi passada
    for(int i = 0; i < argc; i++) {
        if(argv[i][0] == '-') {
            if (argv[i][1] == 'l' || argv[i][1] == 'L') { // Análise léxica
                option = 0;
            } else if (argv[i][1] == 'p' || argv[i][1] == 'P') { // Análise sintática
                option = 1;
            } else if (argv[i][1] == 's' || argv[i][1] == 'S') { // Análise semântica
                option = 2;
            } else {
                printf("Invalid option\n");
                return 1;
            }
        }
    }

    // Se nenhuma flag foi passada, executa todos os analisadores
    if (option == -1) {
        run_all = 1;
    }

    fp = fopen(argv[1], "r"); // Abre o arquivo
    if (fp == NULL) {
        printf("Error opening file %s\n", argv[1]);
        return 1;
    }

    /*Inicialização do buffer*/
    int buffer_size = 20; 
    buffer = allocate_buffer(buffer_size);
    if (buffer == NULL) {
        return 1;
    }

    /*Inicialização do lex*/
    lex = allocate_lex();
    int token;
    char *token_name;

    // Adiciona funções built-in input e output na tabela de símbolos
    AASNode *inputFunc = newAASNodeStmt(KFunc);
    inputFunc->name = copyString("input");
    inputFunc->type = KInt; // ou KVoid, dependendo do seu design
    inputFunc->escopo = copyString("global");
    insertTabSimb(simbTable, inputFunc);
    AASNode *outputFunc = newAASNodeStmt(KFunc);
    outputFunc->name = copyString("output");
    outputFunc->type = KVoid;
    outputFunc->escopo = copyString("global");
    insertTabSimb(simbTable, outputFunc);

    if (run_all) {
        yyparse();
        // Print tree to file
        FILE *ftree = fopen("tree.txt", "w");
        if (ftree && root) {
            printAAS(root, 0, ftree);
            fclose(ftree);
            printf("Tree written to tree.txt\n");
        } else {
            printf("Could not write tree.\n");
        }
        // Print symbol table to file
        FILE *fsymb = fopen("symbol_table.txt", "w");
        if (fsymb && root) {
            printTabSimb(simbTable, root, fsymb);
            fclose(fsymb);
            printf("Symbol table written to symbol_table.txt\n");
        } else {
            printf("Could not write symbol table.\n");
        }
        FILE *finter = fopen("intermediate.txt", "w");
        if (finter && root) {
            QuadNode* quadList = generateIntermediateCodeWithList(root, finter);
            printQuadList(quadList, stdout); // Print all quads to stdout
            fclose(finter);
            printf("Intermediate code written to intermediate.txt\n");
        } else {
            printf("Could not write intermediate code.\n");
        }
    } else if (option == 0) { // Análise léxica
        do{
            token = yylex();
            token_name = get_token_name(token);
            if (token == ER) {
                break;
            }
            else {
                printf("%s\t'%s' \t[linha: %d]\n", token_name, lex->lexema, lex->line + 1);
            }
        } while (token != EOF && token != ER);
    } else if (option == 1) { // Análise sintática
        yyparse();
        FILE *ftree = fopen("tree.txt", "w");
        if (ftree && root) {
            printAAS(root, 0, ftree);
            fclose(ftree);
            printf("Tree written to tree.txt\n");
        } else {
            printf("Could not write tree.\n");
        }
    } else if (option == 2) { // Análise semântica
        yyparse();
        if (root == NULL) {
            printf("Erro na análise sintática\n");
            return 1;
        }
        else {
            FILE *fsymb = fopen("symbol_table.txt", "w");
            if (fsymb && root) {
                printTabSimb(simbTable, root, fsymb);
                fclose(fsymb);
                printf("Symbol table written to symbol_table.txt\n");
            } else {
                printf("Could not write symbol table.\n");
            }
        }
    }

    fclose(fp);

    /*Desalocação de memória*/
    deallocate_buffer(buffer);
    deallocate_lex(lex);
    if (root != NULL) {
        deallocateAAS(root);
    }
    deallocateTabSimb(simbTable);

    return 0;
}