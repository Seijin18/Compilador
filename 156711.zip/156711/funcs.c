#include "funcs.h"
#include "bison.tab.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define AC -9
#define ER -10

char simbolos[] = {'+', '-', '*', '/', '<', '>', '=', '!', ';', ',', '(', ')', '[', ']', '{', '}', '.'}; // Simbolos

// Flag
int read_next = 1;

// Char buffer
char c = '\0';

// Texto de erro semântico
char *semantic_error = NULL;

char *get_token_name(int token) // Retorna o nome do token
{
    switch (token)
    {
    case ID:
        return "ID";
    case NUM:
        return "NUM";
    case ELSE:
        return "ELSE";
    case IF:
        return "IF";
    case INT:
        return "INT";
    case RETURN:
        return "RETURN";
    case VOID:
        return "VOID";
    case WHILE:
        return "WHILE";
    case SOMA:
        return "SOMA";
    case SUB:
        return "SUB";
    case MULT:
        return "MULT";
    case DIV:
        return "DIV";
    case ATR:
        return "ATR";
    case COMP:
        return "COMP";
    case DIF:
        return "DIF";
    case GT:
        return "GT";
    case LT:
        return "LT";
    case GE:
        return "GE";
    case LE:
        return "LE";
    case PTV:
        return "PTV";
    case VIR:
        return "VIR";
    case APAR:
        return "APAR";
    case FPAR:
        return "FPAR";
    case ACOL:
        return "ACOL";
    case FCOL:
        return "FCOL";
    case ACHV:
        return "ACHV";
    case FCHV:
        return "FCHV";
    case CMT:
        return "CMT";
    case EOF:
        return "EOF";
    default:
        return "ERRO";
    }
}

// Letra: 0
// Digito: 1
// White space: 2
// Simbolos: 3 - 18

// DFA
int dfa[27][20] = {
    { 2,  1,  0,  3,  4,  5,  6, 12, 11,  7,  9, 15, 16, 17, 18, 19, 20, 21, 22, ER},          // 0
    {ER,  1, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER},  // 1
    { 2, ER, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER},  // 2
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 3
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 4
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 5
    {AC, AC, AC, AC, AC, 23, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 6
    {AC, AC, AC, AC, AC, AC, AC, AC, AC,  8, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER},  // 7
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 8
    {ER, ER, ER, ER, ER, ER, ER, ER, ER, 10, ER, ER, ER, ER, ER, ER, ER, ER, ER, ER}, // 9
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 10
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, 13, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 11
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, 14, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 12
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 13
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 14
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 15
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 16
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 17
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 18
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 19
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 20
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 21
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}, // 22
    {23, 23, 23, 23, 23, 25, 24, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23}, // 23
    {23, 23, 23, 23, 23, ER, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23}, // 24
    {23, 23, 23, 23, 23, 23, 26, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23}, // 25
    {AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, AC, ER}  // 26
};

Bloco *allocate_buffer(int size) // Aloca o buffer
{
    Bloco *buffer = malloc(sizeof(Bloco));
    if (buffer == NULL)
    {
        printf("Error allocating memory\n");
        return NULL;
    }

    buffer->buffer = malloc(sizeof(char) * size);
    if (buffer->buffer == NULL)
    {
        printf("Error allocating memory\n");
        free(buffer);
        return NULL;
    }

    // Inicializa o buffer
    buffer->buffer[0] = '\0';
    buffer->char_pos = 0;
    buffer->line = 0;
    buffer->size = size;

    return buffer;
}

void deallocate_buffer(Bloco *buffer) // Desaloca o buffer
{
    free(buffer->buffer);
    free(buffer);
}

char get_next_char(Bloco *buffer, FILE *file) // Pega o próximo caractere
{
    char ch;
    ch = buffer->buffer[buffer->char_pos];
    buffer->column += 1;
    if (ch == '\0') // Se chegou no final do buffer
    {
        load_buffer(buffer, file);
        ch = buffer->buffer[buffer->char_pos];
    }
    if (ch == '\n') // Se chegou no final da linha
    {
        buffer->column = 0;
        buffer->line++;
    }

    buffer->char_pos++;
    return ch;
}

void load_buffer(Bloco *buffer, FILE *file) // Carrega o buffer
{
    char ch;
    buffer->char_pos = 0;
    do // Pega o próximo caractere do arquivo até o final da linha ou do arquivo ou do buffer
    {
        ch = fgetc(file); 
        buffer->buffer[buffer->char_pos] = ch;
        buffer->char_pos++;
    } while (c != EOF && ch != '\n' && buffer->char_pos < buffer->size - 2);

    if (ch == EOF && buffer->char_pos < buffer->size - 2)
    {
        buffer->buffer[buffer->char_pos] = EOF;
    }
    else
    {
        buffer->buffer[buffer->char_pos] = '\0';
    }

    buffer->char_pos = 0;
}

void replace_print(Bloco *buffer, int size) // Troca as letras maiúsculas pelas minúsculas e vice-versa
{
    for (int i = 0; i < size; i++)
    {
        if ('A' <= buffer->buffer[i] && buffer->buffer[i] <= 'Z')
        {
            buffer->buffer[i] = buffer->buffer[i] + 32;
        }
        else if ('a' <= buffer->buffer[i] && buffer->buffer[i] <= 'z')
        {
            buffer->buffer[i] = buffer->buffer[i] - 32;
        }
    }

    printf("%s\n", buffer->buffer);
}

int is_symbol(char ch) // Verifica se é um símbolo
{
    for (int i = 0; i < 17; i++)
    {
        if (ch == simbolos[i])
        {
            return i + 3;
        }
    }
    return 0;
}

int is_char(char ch) // Verifica se é uma letra
{
    if (('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z'))
    {
        return 1;
    }
    return 0;
}

int is_digit(char ch) // Verifica se é um dígito
{
    if ('0' <= ch && ch <= '9')
    {
        return 1;
    }
    return 0;
}

int is_space(char ch) // Verifica se é um espaço
{
    if (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\0' || ch == '\r' || ch == '\v' || ch == '\f' || ch == '\b' || ch == EOF)
    {
        return 1;
    }
    return 0;
}

Lex *allocate_lex() // Aloca o lexema
{
    Lex *lex = malloc(sizeof(Lex));
    if (lex == NULL)
    {
        printf("Error allocating memory\n");
        return NULL;
    }

    lex->lexema = malloc(sizeof(char) * 64);
    if (lex->lexema == NULL)
    {
        printf("Error allocating memory\n");
        free(lex);
        return NULL;
    }

    // Inicializa o lexema
    lex->token = 0;
    lex->line = 0;
    lex->column = 0;

    return lex;
}

void deallocate_lex(Lex *lex) // Desaloca o lexema
{
    free(lex->lexema);
    free(lex);
}

void clear_lex(Lex *lex) // Limpa o lexema
{
    for (int i = 0; i < 64; i++)
    {
        lex->lexema[i] = '\0';
    }
    lex->token = 0;
    lex->line = 0;
}

int check_token(int table_state) // Verifica o token do estado da tabela
{
    switch (table_state)
    {
    case 1:
        return NUM;
    case 2:
        return ID;
    case 3:
        return SOMA;
    case 4:
        return SUB;
    case 5:
        return MULT;
    case 6:
        return DIV;
    case 7:
        return ATR;
    case 8:
        return COMP;
    case 10:
        return DIF;
    case 11:
        return GT;
    case 12:
        return LT;
    case 13:
        return GE;
    case 14:
        return LE;
    case 15:
        return PTV;
    case 16:
        return VIR;
    case 17:
        return APAR;
    case 18:
        return FPAR;
    case 19:
        return ACOL;
    case 20:
        return FCOL;
    case 21:
        return ACHV;
    case 22:
        return FCHV;
    case 26:
        return CMT;
    default:
        return -1;
    }
}

int check_keyword(char *lexema) // Verifica se é uma palavra reservada
{
    if (strcmp(lexema, "else") == 0)
    {
        return ELSE;
    }
    else if (strcmp(lexema, "if") == 0)
    {
        return IF;
    }
    else if (strcmp(lexema, "int") == 0)
    {
        return INT;
    }
    else if (strcmp(lexema, "return") == 0)
    {
        return RETURN;
    }
    else if (strcmp(lexema, "void") == 0)
    {
        return VOID;
    }
    else if (strcmp(lexema, "while") == 0)
    {
        return WHILE;
    }
    return ID;
}

int get_terminal(char ch) // Verifica o terminal do autômato
{
    if (is_char(ch))
    {
        return 0;
    }
    else if (is_digit(ch))
    {
        return 1;
    }
    else if (is_space(ch))
    {
        return 2;
    }
    else if (is_symbol(ch))
    {
        return is_symbol(ch);
    }
    return ER;
}

int get_token(Lex *lex, Bloco *buffer, FILE *file) // Pega o token
{
    int state = 0;
    int table_state = 0;
    int i = 0;

    while (state != ER) // Itera até encontrar um estado de erro ou aceitação
    {
        if (c == EOF && !read_next)
        {
            return EOF;
        }
        if (read_next) // Pega o próximo caractere somente após a primeira iteração ou caso a ultima leitura tenha sido um espaço
        {
            c = get_next_char(buffer, file);
            if (c == EOF)
            {
                read_next = 0;
                table_state = dfa[state][2];
                if (table_state == ER)
                {
                    return ER;
                }
                else if (table_state == AC)
                {
                    return check_token(state);
                }
                return ER;
            }
        }
        read_next = 1;
        table_state = dfa[state][get_terminal(c)];
        if (table_state == ER)
        {
            return ER;
        }
        else if (table_state == AC)
        {
            read_next = 0;
            lex->lexema[i] = '\0';
            return check_token(state);
        }
        if (!is_space(c))
        {
            lex->lexema[i] = c;
            i++;
        }
        state = table_state;
    }
    return ER;
}

int get_lexema(Bloco *buffer, Lex *lex, FILE *file) // Pega o lexema
{
    int i = 0;
    clear_lex(lex);
    if (buffer->buffer[buffer->char_pos] == '\0') // Carrega o buffer se estiver no final
    {
        load_buffer(buffer, file);
    }

    // Pega o próximo token
    lex->token = get_token(lex, buffer, file);
    lex->line = buffer->line;
    lex->column = buffer->column - 1;

    if (lex->token == ID)
    {
        lex->token = check_keyword(lex->lexema);
    }

    if (lex->token == ER)
    {
        return ER;
    }
    if (lex->token == EOF)
    {
        return EOF;
    }

    // printf("Lex: %s\n", lex->lexema);
    // printf("Token: %d\n", lex->token);
    // printf("Line: %d\n", lex->line + 1);
    // printf("Column: %d\n", lex->column);
    return lex->token;
}

AASNode *newAASNode(StmtKind kstmt, ExpKind kexp) // Aloca um novo nó
{
    AASNode *node = calloc(1, sizeof(AASNode));
    if (node == NULL)
    {
        printf("Error allocating memory\n");
        return NULL;
    }

    // Inicializa o nó
    node->children = NULL;
    node->sibling = NULL;
    node->token = 0;
    node->value = 0;
    node->name = NULL;
    node->line = 0;
    node->node = KStmt;
    node->stmt = kstmt;
    node->exp = kexp;
    node->type = KInt;

    return node;
}

AASNode *newAASNodeExp(ExpKind kexp) // Aloca um novo nó de expressão
{
    AASNode *node = calloc(1, sizeof(AASNode));
    if (node == NULL)
    {
        printf("Error allocating memory\n");
        return NULL;
    }

    node->children = NULL;
    node->sibling = NULL;
    node->token = 0;
    node->value = 0;
    node->name = NULL;
    node->line = 0;
    node->node = KExp;
    node->stmt = -1;
    node->exp = kexp;
    node->type = KInt;

    return node;
}

AASNode *newAASNodeStmt(StmtKind kstmt) // Aloca um novo nó de declaração
{
    AASNode *node = calloc(1, sizeof(AASNode));
    if (node == NULL)
    {
        printf("Error allocating memory\n");
        return NULL;
    }

    node->children = NULL;
    node->sibling = NULL;
    node->token = 0;
    node->value = 0;
    node->name = NULL;
    node->line = 0;
    node->node = KStmt;
    node->stmt = kstmt;
    node->exp = -1;
    node->type = KInt;

    return node;
}

AASNode *addAASNode(AASNode *node, AASNode *child) // Adiciona um nó filho
{
    if (node->children == NULL)
    {
        node->children = child;
    }
    else
    {
        AASNode *temp = node->children;
        while (temp->sibling != NULL) // Vai até o último filho
        { 
            temp = temp->sibling;
        }
        temp->sibling = child;
    }
    return node;
}

AASNode *addAASNodeSibling(AASNode *node, AASNode *sibling) // Adiciona um nó irmão
{
    AASNode *temp = node;
    while (temp->sibling != NULL) // Vai até o último irmão
    {
        temp = temp->sibling;
    }
    temp->sibling = sibling;
    return node;
}

void updateEscopo(AASNode *node, char *escopo) // Atualiza o escopo
{
    if (node == NULL)
    {
        return;
    }

    while (node != NULL) // Atualiza o escopo de todos os nós descendentes
    {
        node->escopo = copyString(escopo);
        if (node->children != NULL)
        {
            updateEscopo(node->children, escopo);
        }
        node = node->sibling;
    }
}

void printAAS(AASNode *node, int depth, FILE *out) // Imprime a árvore abstrata de sintaxe em arquivo
{
    if (node == NULL)
    {
        return;
    }
    for (int i = 0; i < depth; i++)
    {
        fprintf(out, "----");
    }
    switch (node->node)
    {
    case KStmt:
        fprintf(out, "Stmt: ");
        switch (node->stmt)
        {
        case KIf:
            fprintf(out, "If\n");
            break;
        case KWhile:
            fprintf(out, "While\n");
            break;
        case KAssign:
            fprintf(out, "Assign\n");
            break;
        case KReturn:
            fprintf(out, "Return: %s\n", getTypeName(node->type));
            break;
        case KCall:
            fprintf(out, "Call\n");
            break;
        case KVar:
            fprintf(out, "Var\n");
            break;
        case KVet:
            fprintf(out, "Vet\n");
            break;
        case KFunc:
            fprintf(out, "Func: %s\n", node->name);
            break;
        case KProg:
            fprintf(out, "Prog\n");
            break;
        case KInput:
            fprintf(out, "Input\n");
            break;
        case KOutput:
            fprintf(out, "Output\n");
            break;
        }
        break;
    case KExp:
        fprintf(out, "Exp: ");
        switch (node->exp)
        {
        case KOp:
            fprintf(out, "Op: %s\n", get_token_name(node->token));
            break;
        case KConst:
            fprintf(out, "Const: %d\n", node->value);
            break;
        case KId:
            fprintf(out, "Id: %s\n", node->name);
            break;
        case KType:
            fprintf(out, "Type: %s\n", getTypeName(node->type));
            break;
        case KVarId:
            fprintf(out, "VarId: %s\n", node->name);
            break;
        case KVetId:
            fprintf(out, "VetId\n");
            break;
        }
        break;
    }
    AASNode *child;
    child = node->children;
    while (child != NULL)
    {
        printAAS(child, depth + 1, out);
        child = child->sibling;
    }
}

void printTabSimb(SimbCell *tabSimb, AASNode *node, FILE *out) // Imprime o cabeçalho da tabela de símbolos e chama a função de construção
{
    fprintf(out, "Formato da Tabela de Simbolos:\n");
    fprintf(out, "Nome;\tEscopo;\tTipo;\tTipo de Identificador;\tLinha\n");
    buildTabSimb(tabSimb, node, out);
}

int buildTabSimb(SimbCell *tabSimb, AASNode *node, FILE *out) // Constroi a tabela de símbolos
{
    if (node == NULL)
    {
        return 0;
    }
    char kind[9];
    AASNode *child = node->children;
    int k = 0;
    while (child != NULL) // Percorre todos os nós da árvore
    {
        k = insertTabSimb(tabSimb, child);
        if (k == -1) // Verifica se houve erro semântico
        {
            fprintf(out, "%s: %s [linha: %d]\n", semantic_error, child->name, child->line + 1);
            return -1;
        }
        else if (k == 1) // Insere na tabela de símbolos
        {
            if (child->stmt == KFunc && (strcmp(child->name, "input") == 0 || strcmp(child->name, "output") == 0)) {
                // skip
            } else if (child->stmt == KVar || child->stmt == KVet || child->exp == KVarId || child->exp == KVetId || child->exp == KId) // Verifica o tipo de identificador
            {
                strcpy(kind, "Variable");
                fprintf(out, "%s;\t%s;\t%s;\t%s;\t\t%d\n", child->name, child->escopo, getTypeName(child->type), kind, child->line + 1);
            }
            else
            {
                strcpy(kind, "Function");
                fprintf(out, "%s;\t%s;\t%s;\t%s;\t\t%d\n", child->name, child->escopo, getTypeName(child->type), kind, child->line + 1);
            }
        }
        if (buildTabSimb(tabSimb, child, out) == -1)
        {
            return -1;
        }
        child = child->sibling;
    }
    return 0;
}

void deallocateAAS(AASNode *node) // Desaloca a árvore abstrata de sintaxe
{
    if (node == NULL)
    {
        return;
    }

    AASNode *child = node->children;
    while (child != NULL) // Desaloca todos os filhos e irmãos
    {
        AASNode *temp = child;
        child = child->sibling;
        deallocateAAS(temp);
    }

    if (node->name != NULL)
    {
        free(node->name);
        node->name = NULL; // Set to NULL to avoid double free
    }
    if (node->escopo != NULL)
    {
        free(node->escopo);
        node->escopo = NULL; // Set to NULL to avoid double free
    }
    free(node);
}

char *copyString(char *src) // Copia uma string
{
    int n;
    char *dest;
    if (src == NULL)
    {
        dest = NULL;
        return dest;
    }
    n = strlen(src);
    dest = calloc(n + 1, sizeof(char)); // Aloca memória para a string
    if (dest == NULL)
    {
        printf("Error allocating memory to the destination string\n");
        return dest;
    }
    strncpy(dest, src, n);
    return dest;
}

char *getTypeName(TypeKind type) // Retorna o nome do tipo
{
    switch (type)
    {
    case KInt:
        return "int";
    case KVoid:
        return "void";
    default:
        return "ERRO";
    }
}

static int hash(char *name) // Função de hash
{
    if (name == NULL)
    {
        return -1;
    }

    int temp = 0;
    int i = 0;
    while (name[i] != '\0') // Calcula o hash
    {
        temp = ((temp << 4) + name[i]) % MAX;
        ++i;
    }
    return temp;
}

SimbCell *searchTabSimb(SimbCell *tab, char *name, char *escopo) // Procura na tabela de símbolos
{
    int h = hash(name); // Calcula o hash
    SimbCell *cell, *sibling;
    cell = &tab[h]; // Pega a célula na posição do hash
    while (cell != NULL) // Percorre na tabela de símbolos até encontrar o nome e escopo
    {
        if (cell->name == NULL)
        {
            return NULL;
        }
        if (strcmp(cell->name, name) == 0)
        {
            if ((strcmp(cell->escopo, escopo) == 0) || (strcmp(cell->escopo, "global") == 0)) // Verifica se o escopo é o mesmo ou se é global
            {
                return cell;
            }
            else
            {
                sibling = cell->sibling;
                while (sibling != NULL) // Verifica se o irmão tem o mesmo nome e escopo
                {
                    if (strcmp(sibling->name, name) == 0)
                    {
                        if ((strcmp(sibling->escopo, escopo) == 0 || strcmp(sibling->escopo, "global") == 0))
                        {
                            return sibling;
                        }
                    }
                    sibling = sibling->sibling;
                }
            }
        }
        cell = cell->next;
    }
    return NULL;
}

void insertHash(SimbCell *tab, char *name, char *escopo, TypeKind type, IdKind kind, int line, int hash) // Insere na tabela de símbolos
{
    if (name == NULL)
    {
        return;
    }
    SimbCell *cell = &tab[hash];
    if (cell->name == NULL)
    {
        cell->name = copyString(name);
        cell->escopo = copyString(escopo);
        cell->type = type;
        cell->IdKind = kind;
        cell->line = line;
        cell->next = NULL;
        cell->sibling = NULL;
        return;
    }

    SimbCell *newCell = (SimbCell *)calloc(1, sizeof(SimbCell));
    if (newCell == NULL)
    {
        printf("Error allocating memory\n");
        return;
    }

    newCell->name = copyString(name);
    newCell->escopo = copyString(escopo);
    newCell->type = type;
    newCell->IdKind = kind;
    newCell->line = line;
    newCell->next = NULL;
    newCell->sibling = NULL;

    while (cell->next != NULL && strcmp(cell->name, name) != 0) // Verificar se a célula já existe
    {
        cell = cell->next;
    }
    if (cell->next == NULL)
    {
        cell->next = newCell;
    }
    else // Se a célula já existe, insere o novo nó como irmão
    {
        SimbCell *sibling = cell->sibling;
        if (sibling == NULL)
        {
            cell->sibling = newCell;
        }
        else
        {
            while (sibling->next != NULL)
            {
                sibling = sibling->sibling;
            }
            sibling->sibling = newCell;
        }
    }
}

int insertTabSimb(SimbCell *tab, AASNode *node) // Insere na tabela de símbolos
{
    int h = hash(node->name);
    if (h == -1) // Hash inválido
    {
        return 0; // Pular a inserção
    }

    switch (node->node) // Verifica o tipo do nó
    {
    case KStmt: // Verifica o tipo de declaração
        if (node->stmt == KVar || node->stmt == KVet) // Verifica se é uma variável ou vetor
        {
            if (node->type == KVoid) // Declaração de tipo void
            {
                semantic_error = "Declaracao de tipo void para a variavel";
                return -1;
            }
            if (searchTabSimb(tab, node->name, node->escopo) != NULL) // Verifica se a variável já foi declarada
            {
                semantic_error = "Redeclaração da variável";
                return -1;
            }
            else
            {
                insertHash(tab, node->name, node->escopo, node->type, Var, node->line, h);
                return 1;
            }
        }
        else if (node->stmt == KFunc) // Verifica se é uma função
        {
            // Não insere nem imprime input/output como funções do usuário
            if ((strcmp(node->name, "input") == 0 || strcmp(node->name, "output") == 0)) {
                return 0;
            }
            if (searchTabSimb(tab, node->name, "global") != NULL) // Verifica se a função já foi declarada
            {
                semantic_error = "Redeclaração da função";
                return -1;
            }
            else
            {
                insertHash(tab, node->name, "global", node->type, Func, node->line, h);
                return 1;
            }
        }
        else if (node->stmt == KCall) // Verifica se é uma chamada de função
        {
            SimbCell *aux = searchTabSimb(tab, node->name, "global");
            if (aux == NULL) // Verificar se a função foi declarada
            {
                semantic_error = "Função não declarada";
                return -1;
            }
            else if (node->children != NULL) // Verificar se os argumentos são válidos
            {
                AASNode *child = node->children;
                while (child != NULL)
                {
                    if (child->stmt == KCall) // Funcao como argumento
                    {
                        SimbCell *aux = searchTabSimb(tab, child->name, "global");
                        if (aux == NULL) 
                        {
                            semantic_error = "Função não declarada";
                            free(node->name);
                            node->name = copyString(child->name);
                            return -1;
                        }
                        else if (aux->type == KVoid)
                        {
                            semantic_error = "Tipos incompatíveis";
                            return -1;
                        }
                    }
                    child = child->sibling;
                }
            }               
            {
                insertHash(tab, node->name, node->escopo, node->type, Func, node->line, h);
                return 1;
            }
        }
        else if (node->stmt == KAssign) // Verifica se é uma atribuição
        {
            if (node->type == KVoid) // Verifica se é uma atribuição de tipo void
            {
                semantic_error = "Atribuição de tipo void para a variável";
                return -1;
            }
            else if (node->children->sibling->stmt == KCall) // Verifica se tem uma chamada de função
            {
                SimbCell *aux = searchTabSimb(tab, node->children->sibling->name, "global");
                if (aux == NULL)
                {
                    semantic_error = "Função não declarada";
                    free(node->name);
                    node->name = copyString(node->children->sibling->name);
                    return -1;
                }
                else if (aux->type != node->type)
                {
                    semantic_error = "Atribuição com tipos incompatíveis";
                    return -1;
                }
                else
                {
                    return 1;
                }
            }
            else if (node->type != node->children->type != node->children->sibling->type) // Verifica se os tipos são compatíveis
            {
                semantic_error = "Tipos incompatíveis";
                return -1;
            }
            else
            {
                return 1;
            }
        }
        else if (node->stmt == KReturn) // Verifica se é um retorno
        {
            SimbCell *aux = searchTabSimb(tab, node->escopo, "global");
            if (aux->type != node->type) // Verifica se os tipos da função e do retorno são compatíveis
            {
                semantic_error = "Retorno com tipos incompatíveis";
                return -1;
            }
            else
            {
                return 1;
            }
        }
        break;

    case KExp: // Verifica o tipo de expressão
        if (node->exp == KVarId || node->exp == KVetId) // Verifica se é uma variável ou vetor
        {
            SimbCell *aux = searchTabSimb(tab, node->name, node->escopo); // Verifica se a variável foi declarada no escopo
            if (aux == NULL)
            {
                aux = searchTabSimb(tab, node->name, "global"); // Verifica se a variável foi declarada globalmente
                if (aux == NULL)
                {
                    semantic_error = "Variável não declarada";
                    return -1;
                }
                else
                {
                    insertHash(tab, node->name, "global", node->type, Var, node->line, h);
                    return 1;
                }
            }
            else
            {
                insertHash(tab, node->name, node->escopo, node->type, Var, node->line, h);
                return 1;
            }
        }
        break;
    }
}

void deallocateTabSimb(SimbCell *tabSimb) // Desaloca a tabela de símbolos
{
    if (tabSimb == NULL) return;
    for (int i = 0; i < MAX; i++) {
        SimbCell *cell = &tabSimb[i];
        // Free the main cell if it was allocated (skip if name is NULL)
        if (cell->name != NULL) {
            free(cell->name);
            cell->name = NULL;
        }
        if (cell->escopo != NULL) {
            free(cell->escopo);
            cell->escopo = NULL;
        }
        // Free siblings
        SimbCell *sibling = cell->sibling;
        while (sibling != NULL) {
            SimbCell *nextSibling = sibling->sibling;
            if (sibling->name) free(sibling->name);
            if (sibling->escopo) free(sibling->escopo);
            free(sibling);
            sibling = nextSibling;
        }
        cell->sibling = NULL;
        // Free the linked list (next)
        SimbCell *next = cell->next;
        while (next != NULL) {
            SimbCell *tmp = next->next;
            if (next->name) free(next->name);
            if (next->escopo) free(next->escopo);
            // Also free any siblings of this next cell
            SimbCell *sib = next->sibling;
            while (sib != NULL) {
                SimbCell *sibNext = sib->sibling;
                if (sib->name) free(sib->name);
                if (sib->escopo) free(sib->escopo);
                free(sib);
                sib = sibNext;
            }
            free(next);
            next = tmp;
        }
        cell->next = NULL;
    }
}